﻿(function () {
    "use strict";

    angular
        .module("usersManagement")
        .controller("userAddCtrl",
        UserAddCtrl);

    function UserAddCtrl(usersResource,$scope) {
        var vm = this;
        vm.showList = true;
        vm.users = [];
        vm.showNewUserForm = false;
         usersResource.get({ id: 0 },
           function (data) {
                vm.newUser = data;
            
                vm.originalProduct = angular.copy(data);
            });

      


      

        function getRepo() {
            usersResource.query(function (data) {
              
                vm.users = data;
             
                
             
          });

          
           
        }

        vm.newUser = {
            name:"john doe",
            email:"johnDoe@email.com",
            phonenumber:"302-740-8075"
        }

        vm.newUserHolder = angular.copy(vm.newUser);

        vm.message = '';


        

        
        if (vm.newUser) {
            vm.title = "Add User: ";
        }
        else {
            vm.title = "Add User";
        }

        vm.submit = function () {




            vm.newUser.$save(
                function (data) {
                    console.log(data);
                    if (data.status === 400) {
                        vm.message = "You have validations issues";
                    }

                    else {
                        vm.message = "...Save Complete";

                        getRepo();
                        vm.showNewUserForm = false;
                    }




                }, function (error) {
                    if (error.status === 400) {
                        vm.message = "You have validations issues";
                    }
                   
                });
               

          

            


        };

        vm.showForm = function ()
        {
            vm.showNewUserForm = true;

        }

        vm.cancel = function (editForm) {
            editForm.$setPristine();
            vm.newUser = {
                email: "",
                name: "",
                phonenumber:""

            }


            vm.message = "";
        };
        getRepo();

    }
}());