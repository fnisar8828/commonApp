﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using CommonApp2.Models;
using System.Web.Http.Cors;

namespace CommonApp2.Controllers
{
    [EnableCorsAttribute("*", "*","*")]
    public class UsersController : ApiController
    {



        // GET: api/user
        public IEnumerable<User> Get()
        {

            var userRepository = new UserRepository();
            return userRepository.Retrieve();
        }

        // GET: api/user/5
        public void Get(int id)
        {
            
        }

        // POST: api/user
        public HttpResponseMessage Post([FromBody] User user)
        {
            if (ModelState.IsValid)
            {
                var userRepository = new Models.UserRepository();
                var newUser = userRepository.Save(user);
                return new HttpResponseMessage(HttpStatusCode.OK);

            }
            else
            {
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, ModelState);

            }
        }

        // PUT: api/user/5
        public void Put([FromBody] User user)
        {
            var userRepository = new Models.UserRepository();
            var newUser = userRepository.Save(user);


        }

        // DELETE: api/user/5
        public void Delete(int id)
        {
        }
    }
}
