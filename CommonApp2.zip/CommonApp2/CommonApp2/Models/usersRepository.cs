﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Hosting;

namespace CommonApp2.Models
{
    /// <summary>
    /// Stores the data in a json file so that no database is required for this
    /// sample application
    /// </summary>
    public class UserRepository
    {
        /// <summary>
        /// Creates a new product with default values
        /// </summary>
        /// <returns></returns>
        internal User Create()
        {
            User user = new User
            {
               
            };
            return user;
        }

        /// <summary>
        /// Retrieves the list of users.
        /// </summary>
        /// <returns></returns>
        internal List<User> Retrieve()
        {
            var filePath = HostingEnvironment.MapPath(@"~/App_Data/users.json");

            var json = System.IO.File.ReadAllText(filePath);

            var users = JsonConvert.DeserializeObject<List<User>>(json);

            return users;
        }

        /// <summary>
        /// Saves a new product.
        /// </summary>
        /// <param name="product"></param>
        /// <returns></returns>
        internal User Save(User user)
        {
            // Read in the existing products
            var users = this.Retrieve();

            // Assign a new Id
            var maxId = users.Max(u => u.id);
            user.id = maxId + 1;
            users.Add(user);

            WriteData(users);
            return user;
        }

        /// <summary>
        /// Updates an existing product
        /// </summary>
        /// <param name="id"></param>
        /// <param name="product"></param>
        /// <returns></returns>
        internal User Save(int id, User user)
        {
            // Read in the existing products
            var users = this.Retrieve();

            // Locate and replace the item
            var itemIndex = users.FindIndex(u => u.id == user.id);
            if (itemIndex > 0)
            {
                users[itemIndex] = user;
            }
            else
            {
                return null;
            }

            WriteData(users);
            return user;
        }

        private bool WriteData(List<User> users)
        {
            // Write out the Json
            var filePath = HostingEnvironment.MapPath(@"~/App_Data/users.json");

            var json = JsonConvert.SerializeObject(users, Formatting.Indented);
            System.IO.File.WriteAllText(filePath, json);

            return true;
        }

    }
}